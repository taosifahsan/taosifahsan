/* *****************************************************************************
 *  Name:    Taosif Ahsan
 *  NetID:   tahsan
 *  Precept: P13
 *
 *  Partner Name:    Declan Farmer
 *  Partner NetID:   dfarmer
 *  Partner Precept: P13
 *
 *  Description:  Calculates Boltzmann constant and Avogadro number using
 *                standard inputs
 *
 **************************************************************************** */

public class Avogadro {
    public static void main(String[] args) {

        // initializing variables
        double sum = 0;
        int n = 0;

        // finding the average of pixel displacements
        while (!StdIn.isEmpty()) {
            sum += Math.pow(StdIn.readDouble(), 2);
            n++;
        }

        // calculating displacement and converting it to metric
        double d = sum / (2 * n) * 0.175E-6 * 0.175E-6;

        // calculating Boltmann constant
        double k = 6 * Math.PI * 9.135E-4 * 0.5E-6 / 297.0 * d;

        // calculating Avogadro's Number
        double na = 8.31446 / k;

        // printing the resutls
        System.out.printf("Boltzmann = %5.4e\nAvogadro  = %5.4e\n", k, na);

    }
}
