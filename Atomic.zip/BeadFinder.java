/* *****************************************************************************
 *  Name:    Taosif Ahsan
 *  NetID:   tahsan
 *  Precept: P13
 *
 *  Partner Name:    Declan Farmer
 *  Partner NetID:   dfarmer
 *  Partner Precept: P13
 *
 *  Description:  Creates BeadFinder Object which comtains every light Blobs
 *                in a picture which are found using DFS algorithm. GetBeads
 *                function filters out heavier blobs.
 ******************************************************************************/


import java.awt.Color;

public class BeadFinder {


    private final ST<Integer, Blob> blobST; // stores blobs

    //  finds all blobs in the specified picture using luminance threshold tau
    public BeadFinder(Picture picture, double tau) {
        // initializing blobST

        blobST = new ST<>();
        // necessary measurements
        int width = picture.width();
        int height = picture.height();

        // marker to remember visits
        boolean[][] visit = new boolean[width][height];
        int key = 0;
        // creating blobs
        for (int col = 0; col < width; col++)
            for (int row = 0; row < height; row++) {
                Color color = picture.get(col, row);


                // if the pixel is dark marking visit and moving on
                if (Luminance.intensity(color) < tau) visit[col][row] = true;
                    // else, if it is a new pixel and its light, creating a blob
                    //  adding pixels to it and storing the blob to blobstack
                else {
                    if (!visit[col][row]) {
                        Blob newBlob = new Blob();
                        dfs(picture, visit, newBlob, col, row, tau);
                        blobST.put(key, newBlob);
                        key++;
                    }
                }

            }
    }

    // returns all beads (blobs with >= min pixels)
    public Blob[] getBeads(int min) {

        // Symbol table to hold filtered beads
        ST<Integer, Blob> temp = new ST<>();

        // key variable initialization
        int key = 0;

        // filtering the beads
        for (int i : blobST.keys()) {
            if (blobST.get(i).mass() >= min) {
                temp.put(key, blobST.get(i));
                key++;
            }
        }

        // representing the result into an array
        int n = temp.size();
        Blob[] result = new Blob[n];
        for (int i : temp.keys()) {
            result[i] = temp.get(i);
        }

        // returns the array of beads
        return result;
    }


    // implements dfs algorithm
    private static void dfs(Picture picture, boolean[][] visit,
                            Blob newBlob, int col, int row, double tau) {

        // base cases
        if (col < 0 || col >= picture.width()) return;
        if (row < 0 || row >= picture.height()) return;
        if (visit[col][row]) return;
        if (Luminance.intensity(picture.get(col, row)) < tau) {
            visit[col][row] = true;   // marking the visit and returning
            return;
        }

        // adding pixels and marking the visits
        newBlob.add(col, row);
        visit[col][row] = true;

        // recursively calling dfs for neighbours
        dfs(picture, visit, newBlob, col + 1, row, tau);
        dfs(picture, visit, newBlob, col, row + 1, tau);
        dfs(picture, visit, newBlob, col - 1, row, tau);
        dfs(picture, visit, newBlob, col, row - 1, tau);

    }

    //  test client, as described below
    public static void main(String[] args) {
        // taking command line arguments
        int min = Integer.parseInt(args[0]);
        double tau = Double.parseDouble(args[1]);
        Picture picture = new Picture(args[2]);


        // creating the BeadFinder
        BeadFinder beads = new BeadFinder(picture, tau);

        // getting the beads from the BeadFinder
        Blob[] blob = beads.getBeads(min);

        // Printing the Beads
        for (int i = 0; i < blob.length; i++) {
            System.out.println(blob[i]);
        }

    }
}
