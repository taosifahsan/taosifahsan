/* *****************************************************************************
 *  Name:    Taosif Ahsan
 *  NetID:   tahsan
 *  Precept: P13
 *
 *  Partner Name:    Declan Farmer
 *  Partner NetID:   dfarmer
 *  Partner Precept: P13
 *
 *  Description:  Prints the displacements of every particle for every
 *                consecutive Frames
 ******************************************************************************/

public class BeadTracker {
    public static void main(String[] args) {
        // command line arguments
        int min = Integer.parseInt(args[0]);
        double tau = Double.parseDouble(args[1]);
        double delta = Double.parseDouble(args[2]);

        // number of frames
        int n = args.length - 4;

        // loop over frames
        for (int k = 0; k < n; k++) {

            // getting the pictures
            Picture picture1 = new Picture(args[3 + k]);
            Picture picture2 = new Picture(args[4 + k]);

            // creating beadFinder from two pictures
            BeadFinder bead1 = new BeadFinder(picture1, tau);
            BeadFinder bead2 = new BeadFinder(picture2, tau);

            // extracting the beads from the pictures
            Blob[] blobs1 = bead1.getBeads(min);
            Blob[] blobs2 = bead2.getBeads(min);

            // set of displacements of particles on two franes
            for (int j = 0; j < blobs2.length; j++) {
                double minDistance = Double.POSITIVE_INFINITY;

                // closest particle
                for (int i = 0; i < blobs1.length; i++) {
                    double distance = blobs1[i].distanceTo(blobs2[j]);
                    if (minDistance > distance)
                        minDistance = distance;
                }

                // printing displacements
                if (!(minDistance > delta))
                    System.out.printf("%5.4f\n", minDistance);
            }
        }
    }
}
