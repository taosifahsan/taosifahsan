/* *****************************************************************************
 *  Name:    Taosif Ahsan
 *  NetID:   tahsan
 *  Precept: P13
 *
 *  Partner Name:    Declan Farmer
 *  Partner NetID:   dfarmer
 *  Partner Precept: P13
 *
 *  Description:  Creates Blob object which contains mass and center of mass of
 *                a Blob and creates necessary functions
 *
 **************************************************************************** */

public class Blob {
    private double cx;  // center of mass in x-direction
    private double cy;  // center of mass in y-direction
    private int mass;   // number of pixels


    //  creates an empty blob
    public Blob() {
        cx = 0;
        cy = 0;
        mass = 0;
    }

    //  adds pixel (x, y) to this blob
    public void add(int x, int y) {
        mass++;
        cx = (cx * (mass - 1) + x) / mass;
        cy = (cy * (mass - 1) + y) / mass;
    }

    //  number of pixels added to this blob
    public int mass() {
        return mass;
    }

    //  Euclidean distance between the center of masses of the two blobs
    public double distanceTo(Blob that) {
        if (this.mass == 0 || that.mass() == 0) return Double.NaN;
        return Math.sqrt((that.cx - this.cx) * (that.cx - this.cx)
                                 + (that.cy - this.cy) * (that.cy - this.cy));
    }

    //  string representation of this blob (see below)
    public String toString() {
        if (mass == 0) return "0 (NaN, NaN)";
        return String.format("%2d (%8.4f, %8.4f)", mass, cx, cy);

    }

    //  tests this class by directly calling all instance methods
    public static void main(String[] args) {
        Blob blob = new Blob();
        System.out.println(blob.mass());
        blob.add(900, 400);
        blob.add(300, 300);
        System.out.println(blob);
        Blob blob1 = new Blob();
        blob1.add(200, 400);
        System.out.println(blob1);
        System.out.println(blob.distanceTo(blob1));
    }
}
