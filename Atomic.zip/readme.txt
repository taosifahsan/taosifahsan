/* *****************************************************************************
 *  Name:      Taosif Ahsan
 *  NetID:     tahsan
 *  Precept:   p13
 *
 *  Partner Name:    Declan Farmer
 *  Partner NetID:   dfarmer
 *  Partner Precept: P13
 **************************************************************************** */

Which partner is submitting the program files? Taosif Ahsan

Final Programming Project: Atomic Nature of Matter

Hours to complete assignment (optional): 7


/**************************************************************************
 *  The input size n for BeadTracker is the product of the number of      *
 *  pixels per frame and the number of frames. What is the estimated      *
 *  running time (in seconds) of BeadTracker as a function of n?          *
 *  Justify your answer with empirical data and explain how you used it.  *
 *  Your answer should be of the form a*n^b where b is an integer.        *
 **************************************************************************/
 At first we took datas of only points with 2^n form. But the results had a
pretty broad uncertainity so we took datas of all point with 10*n form. For each
point we took 3 measurements.

number of frames         time in seconds (t)
  10                         0.50
  20                         0.79
  30                         1.06
  40                         1.32
  50                         1.60
  60                         1.90
  70                         2.14
  80                         2.39
  90                         2.70
  100                        2.98
  110                        3.20
  120                        3.50
  130                        3.75
  140                        4.00
  150                        4.27
  160                        4.64
  170                        4.75
  180                        4.99
  190                        5.28
  200                        5.60

  Then we plotted log(t) and log(n), (n=pixel per frame* frame)=640*480*frame

  t=a*n^b
  log(t)=log(a)+b*log(n)

  so the slope is b and y-intersection is log(a).

  After plotting the results were,
  a=1.786*10^-6
  b=0.8314

  So, the power is fraction. It probably happens because the beadfinder function
  does not actually visit every single pixel one by one. There are some randomn
  steps when it starts the recursion. But b is almost close to 1.

  So ,

  t= 1.786 *10^-6 * n^ 0.8319 seconds ~ 1.8*10^-6 * n






/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?

No

/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?

No

/**************************************************************************
 *  List any other comments here.                                         *
 **************************************************************************/
