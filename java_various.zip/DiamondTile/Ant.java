/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */

public class Ant {

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);

        double m = 0, k = 0, x = 0, y = 0, r, theta,
                ratio = Double.parseDouble(args[1]),
                mu = Double.parseDouble(args[2]),
                sigma = Double.parseDouble(args[3]);


        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(-1.5 * ratio * Math.sqrt(n) * (mu + sigma),
                          1.5 * ratio * Math.sqrt(n) * (mu + sigma));
        StdDraw.setYscale(-1.5 * ratio * Math.sqrt(n) * (mu + sigma),
                          1.5 * ratio * Math.sqrt(n) * (mu + sigma));
        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.setPenRadius(0.01);
        StdDraw.point(0, 0);
        for (int i = 0; i < n; i++) {
            m = x;
            k = y;


            r = StdRandom.gaussian(mu, sigma);
            theta = StdRandom.uniform(0, 2 * Math.PI);
            x += r * Math.cos(theta);
            y += r * Math.sin(theta);

            StdDraw.setPenRadius(0.002);
            StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
            StdDraw.line(m, k, x, y);
            StdDraw.setPenColor(StdDraw.PRINCETON_ORANGE);
            StdDraw.setPenRadius(0.01);
            StdDraw.point(x, y);
            StdDraw.pause(40);
            StdDraw.show();

        }

        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.setPenRadius(0.01);
        StdDraw.point(x, y);
        StdDraw.setPenRadius(0.002);
        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.line(0, 0, x, y);
        StdDraw.show();


        double r2 = m * m + k * k;
        System.out.print("x = " + m + "\n");
        System.out.print("y = " + k + "\n");
        System.out.print("squared distance = " + r2 + "\n");

    }
}
