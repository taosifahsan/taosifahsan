


public class Chaos {
    public static void main(String[] args) {
        double size = 50;


        double y0 = 0.0;
        double s0 = 10;
        double p0 = 28;
        double b0 = 8.0 / 3;

        double s = s0;
        double p = p0;
        double b = b0;

        double t, dt = 0.01;
        double n = 100;

        StdDraw.setXscale(-size, size);
        StdDraw.setYscale(-size, size);


        StdDraw.enableDoubleBuffering();

        double x = StdDraw.mouseX();
        double vx;
        double z = StdDraw.mouseX();
        double vz;
        double y = y0;
        double vy;
        double tx = x;
        double tz = z;


        while (true) {

            x = StdDraw.mouseX();
            z = StdDraw.mouseY();
            if (StdDraw.isKeyPressed('Y')) {
                y += 0.1;
            }
            if (StdDraw.isKeyPressed('H')) {
                y -= 0.1;
            }
            if (StdDraw.isKeyPressed('B')) {
                b += 0.1;
            }
            if (StdDraw.isKeyPressed('N')) {
                b -= 0.1;
            }
            if (StdDraw.isKeyPressed('S')) {
                s += 0.1;
            }
            if (StdDraw.isKeyPressed('X')) {
                s -= 0.1;
            }
            if (StdDraw.isKeyPressed('P')) {
                p += 0.01;
            }
            if (StdDraw.isKeyPressed('L')) {
                p -= 0.01;
            }
            if (StdDraw.isKeyPressed(' ')) {

                b = b0;
                s = s0;
                p = p0;
            }
            double tempx = x, tempz = z;
            if (Math.sqrt((x - tx) * (x - tx) + (z - tz) * (z - tz))
                    >= 0.00001) {
                StdDraw.setPenColor(StdDraw.GREEN);
                StdDraw.line(-500, 0, 500, 0);
                StdDraw.line(0, -500, 0, 500);

                StdDraw.setPenColor(StdDraw.BLUE);
                StdDraw.text(size * 0.8, size * .95, "y0 = " +
                        Math.round(y0 * 1000d) / 1000d);
                StdDraw.text(size * 0.8, size * 0.9, "s = " +
                        Math.round(s * 1000d) / 1000d);
                StdDraw.text(size * 0.8, size * 0.85, "p = " +
                        Math.round(p * 1000d) / 1000d);
                StdDraw.text(size * 0.8, size * 0.8, "b = " +
                        Math.round(b * 1000d) / 1000d);


                for (t = 0; t < n; t += dt) {
                    vx = s * (y - x);
                    vy = x * (p - z) - y;
                    vz = x * y - b * z;
                    x += vx * dt;
                    y += vy * dt;
                    z += vz * dt;
                    StdDraw.setPenRadius(0.003);
                    StdDraw.setPenColor(StdDraw.BOOK_LIGHT_BLUE);
                    StdDraw.line(tempx, tempz, x, z);
                    tempx = x;
                    tempz = z;

                }
                StdDraw.show();
                StdDraw.clear(StdDraw.BLACK);
            }
            tx = x;
            tz = z;
        }
    }
}

