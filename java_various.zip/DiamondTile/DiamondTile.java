

public class DiamondTile {

    public static void main(String[] args) {
        int i, x, y, a, b, n, m, k;
        double c = 0.25;
        n = Integer.parseInt(args[0]);
        x = 0;
        y = 0;
        m = 0;
        k = 0;
        double r;

        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(-1.5 * Math.sqrt(n), 1.5 * Math.sqrt(n));
        StdDraw.setYscale(-1.5 * Math.sqrt(n), 1.5 * Math.sqrt(n));
        for (i = 0; i < Integer.parseInt(args[1]); i++) {
            m = x;
            k = y;

            r = StdRandom.uniform(0.0, 1.0);

            if (r < c) a = -1;
            else if (r <= 0.75 && r >= c) a = 0;
            else a = 1;
            x = x + a;
            if (r <= 0.5) b = -1;
            else b = 1;

            if (a == 0) {
                y = y + b;
            }

            StdDraw.setPenRadius(0.005);
            StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
            StdDraw.line(m, k, x, y);
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.setPenRadius(0.007);
            StdDraw.point(x, y);
            StdDraw.pause(40);
            StdDraw.show();

        }
        int r2 = m * m + k * k;
        System.out.print("squared distance = " + r2);

    }
}
