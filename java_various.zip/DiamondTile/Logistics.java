

public class Logistics {
    public static void main(String[] args) {
        int bet = 5000;
        double size = bet;


        double r0 = 2;
        double x0 = 0.5;

        double r = r0;


        double t, dt = 1;
        double n = 2 * size;

        StdDraw.setCanvasSize(1200, 750);
        StdDraw.setXscale(-0.1 * size, 2 * size);
        StdDraw.setYscale(-0.1, 1.3);


        StdDraw.enableDoubleBuffering();

        double x = x0;


        while (true) {

            StdDraw.line(-size*0.01, 1,0.01*size,1);

            if (StdDraw.isKeyPressed('X')) {
                x0 += 0.001;
            }
            if (StdDraw.isKeyPressed('C')) {
                x0 -= 0.001;
            }

            x = x0;


            if (StdDraw.isKeyPressed('R')) {
                r += 0.001;
            }
            if (StdDraw.isKeyPressed('T')) {
                r -= 0.001;
            }
            if (StdDraw.isKeyPressed('E')) {
                r += 0.01;
            }
            if (StdDraw.isKeyPressed('Y')) {
                r -= 0.01;
            }

            double tempx = x;

            StdDraw.setPenColor(StdDraw.GREEN);
            StdDraw.line(-5, 0, 500000, 0);
            StdDraw.line(0, -5, 0, 500);

            StdDraw.setPenColor(StdDraw.BLUE);



            StdDraw.text(size * 1.8, 1, "r = " +
                    Math.round(r * 1000d) / 1000d);


            for (t = 0; t < n; t += dt) {

                x = r * x * (1 - x);
                StdDraw.setPenRadius(0.005);
                StdDraw.setPenColor(StdDraw.BLUE);
                StdDraw.point(t, tempx);

                /*StdDraw.setPenRadius(0.008);
                StdDraw.setPenColor(StdDraw.PRINCETON_ORANGE);
                StdDraw.point(t,
                              (1 - 1 / r) / (1 + ((1 - 1 / r) / x0 - 1) * Math
                                      .exp(-(r - 1) * (t + dt) / dt)));8/
                StdDraw.setPenRadius(0.008);*/
                /*StdDraw.setPenRadius(0.001);
                StdDraw.setPenColor(StdDraw.BOOK_LIGHT_BLUE);
                StdDraw.line(t, tempx, t + dt, x);*/
                tempx = x;


            }
            StdDraw.show();
            StdDraw.clear(StdDraw.BLACK);


        }
    }
}
