public class Randomness {
    public static void main(String[] args) {
        double size = 10;


        double y0 = 0.9;
        double b0 = 0.00;
        double w0 = Math.PI / 2;

        double y = y0;
        double b = b0;
        double w = w0;

        double t, dt = 0.01;
        double n = 100;

        StdDraw.setXscale(-size, size);
        StdDraw.setYscale(-size, size);


        StdDraw.enableDoubleBuffering();
        double ax;
        double x = StdDraw.mouseX();
        double vx = StdDraw.mouseY();
        double tx = x;
        double tvx = vx;


        while (true) {

            x = StdDraw.mouseX();
            vx = StdDraw.mouseY();
            if (StdDraw.isKeyPressed('Y')) {
                y += 0.001;
            }
            if (StdDraw.isKeyPressed('H')) {
                y -= 0.001;
            }
            if (StdDraw.isKeyPressed('B')) {
                b += 0.005;
            }
            if (StdDraw.isKeyPressed('N')) {
                b -= 0.005;
            }
            if (StdDraw.isKeyPressed('W')) {
                w += 0.005;
            }
            if (StdDraw.isKeyPressed('S')) {
                w -= 0.005;
            }
            if (StdDraw.isKeyPressed(' ')) {
                y = y0;
                b = b0;
                w = w0;
            }
            double tempx = x, tempvx = vx;
            if (Math.sqrt((x - tx) * (x - tx) + (vx - tvx) * (vx - tvx))
                    >= 0.00001) {
                StdDraw.setPenColor(StdDraw.GREEN);
                StdDraw.line(-500, 0, 500, 0);
                StdDraw.line(0, -500, 0, 500);

                StdDraw.setPenColor(StdDraw.BLUE);
                StdDraw.text(size * 0.8, size * .95, "y = " +
                        Math.round(y * 1000d) / 1000d);
                StdDraw.text(size * 0.8, size * 0.9, "b = " +
                        Math.round(b * 1000d) / 1000d);
                StdDraw.text(size * 0.8, size * 0.85, "w = " +
                        Math.round(w * 1000d) / 1000d);

                StdDraw.text(size * 0.8, size * 0.8, "x = " +
                        Math.round(x * 1000d) / 1000d);
                StdDraw.text(size * 0.8, size * 0.75, "vx = " +
                        Math.round(vx * 1000d) / 1000d);


                for (t = 0; t < n; t += dt) {
                    ax = -2 * b * vx - Math.sin(x) +
                            y * w0 * w0 * Math.cos(w * t);
                    vx += ax * dt;
                    x += vx * dt + ax * dt * dt / 2;
                    StdDraw.setPenRadius(0.003);
                    StdDraw.setPenColor(StdDraw.BOOK_LIGHT_BLUE);
                    StdDraw.line(tempx, tempvx, x, vx);
                    tempx = x;
                    tempvx = vx;

                }
                StdDraw.show();
                StdDraw.clear(StdDraw.BLACK);
            }
            tx = x;
            tvx = vx;
        }
    }
}
