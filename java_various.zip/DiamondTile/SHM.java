/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */
public class SHM {

    public static void main(String[] args) {

        double r;

        double ystart=0; double yend=20;
        double rstart= Double.parseDouble(args[1]), rend= Double.parseDouble(args[2]);

        double a,v,t,x,dt=0.1;


        double w=2*Math.PI;
        double w0=1.5*w;
        double b=w0/4;
        StdDraw.setCanvasSize(1400, 750);
        StdDraw.setXscale(rstart, rend);
        StdDraw.setYscale(ystart, yend);
        StdDraw.enableDoubleBuffering();

        StdDraw.setPenRadius(0.002);
        StdDraw.setPenColor(StdDraw.BLACK);
        /*StdDraw.line(rstart,0,rend,0);
        StdDraw.line(rstart,ystart+0.1,rstart,yend);
        StdDraw.setPenRadius(0.001);
        for(double i=rstart;i<=rend;i+=0.1)
        {
            StdDraw.text(i+0.02,-0.02,String.format ("%.1f",i));
            StdDraw.line(i,ystart,i,yend);

        }
        for(double i=ystart+0.1;i<=yend;i+=0.5)
        {
            StdDraw.line(rstart,i,rend,i);
            StdDraw.text(rstart*0.99,i+0.01,String.format ("%.1f",i));
        }*/

        for( r=rstart;r<rend;r+=0.00001) {
            x=0;
            v=0;
            t=0;
            while(t<=5*Double.parseDouble(args[0]))
            {

                a=-w0*w0*Math.sin(x)-2*b*v+r*w0*w0*Math.cos(w*t);
                v+=a*dt;
                x+=v*dt+a*dt*dt/2;
                t+=dt;

            }
            for(int i=0;i<Double.parseDouble(args[0]);i++)
            {
                StdDraw.point(r,v);
                while(t<=5*Double.parseDouble(args[0])+i*1)
                {
                    a=-w0*w0*Math.sin(x)-2*b*v+r*w0*w0*Math.cos(w*t);
                    v+=a*dt;
                    x+=v*dt+a*dt*dt/2;
                    t+=dt;
                }
            }
            StdDraw.show();
        }


    }
}
