/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */
public class bifurication {
    private static double f(double x, double r) {
        return r*x*(1-x);
    }
    public static void main(String[] args) {

        double x;
        double ystart=-0.1,yend=1;

        double rstart=3.8;
        double rend=3.9;
        StdDraw.setCanvasSize(1400, 750);
        StdDraw.setXscale(rstart*0.98, rend);
        StdDraw.setYscale(ystart, yend);
        StdDraw.line(rstart,0,rend,0);
        StdDraw.line(rstart,ystart+0.1,rstart,yend);
        StdDraw.setPenRadius(0.001);
        for(double i=rstart;i<=rend;i+=0.05)
        {
            StdDraw.text(i+0.02,-0.02,String.format ("%.2f",i));
            StdDraw.line(i,ystart+0.1,i,yend);

        }
        for(double i=ystart+0.1;i<=yend;i+=0.1)
        {
            StdDraw.line(rstart,i,rend,i);
            StdDraw.text(rstart*0.99,i+0.01,String.format ("%.1f",i));
        }
        StdDraw.enableDoubleBuffering();

        StdDraw.setPenRadius(0.002);
        StdDraw.setPenColor(StdDraw.BLACK);
        for(double r=rstart;r<rend;r+=(rend-rstart)*0.0001) {
            x=0.5;

            for(int i=1;i<=10000;i++)
            {
                x=f(x,r);
            }

            for(int i=1;i<=100;i++)
            {
                StdDraw.point(r,x);
                x=f(x,r);
            }

        }
        StdDraw.save("bifurication.png");
        StdDraw.show();
    }
}
