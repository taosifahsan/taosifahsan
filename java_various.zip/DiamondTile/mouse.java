
public class mouse {
    public static void main(String[] args) {
        StdDraw.setPenRadius(0.05);
        StdDraw.enableDoubleBuffering();
        while (true) {
            if (StdDraw.isMousePressed())
                StdDraw.point(StdDraw.mouseX(), StdDraw.mouseY());
            StdDraw.pause(20);
            StdDraw.show();
            StdDraw.clear();
        }
    }
}
