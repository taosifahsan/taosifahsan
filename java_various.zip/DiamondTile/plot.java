/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */

public class plot {

    public static double function(double x) {
        return x * x;
    }

    public static void main(String[] args) {

        double y;
        int accuracy = 50;
        double rangei = -5;
        double rangef = 5;

        double yMax = rangei, yMin = rangef;

        for (double x = rangei; x < rangef; x += 1.0 / accuracy) {
            y = function(x);
            if (y > yMax) yMax = y;
            if (y < yMin) yMin = y;
        }


        StdDraw.setCanvasSize(1440, 780);
        StdDraw.setXscale(rangei, rangef);
        StdDraw.setYscale(1.1 * yMin, 1.1 * yMax);
        StdDraw.setPenRadius(0.002);
        StdDraw.setPenColor(StdDraw.BLUE);
        StdDraw.line(rangei, 0, rangef, 0);
        StdDraw.line(0, 1.1 * yMin, 0, 1.1 * yMax);

        double cx = rangei, cy = function(rangei);

        for (double x = rangei; x <= rangef; x += 1.0 / accuracy) {
            StdDraw.setPenRadius(0.003);
            StdDraw.setPenColor(StdDraw.BLACK);
            y = function(x);
            StdDraw.line(cx, cy, x, y);
            cx = x;
            cy = y;
        }


        StdDraw.show();
    }
}
