/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */


public class projectile {

    public static void main(String[] args) {
        double size = 100;
        double  dt = 0.00001*size;
        double v = size/100;
        double T;
        StdDraw.setXscale(-0.1*size, 2*size);
        StdDraw.setYscale(-0.1*size, 2*size);

        StdDraw.enableDoubleBuffering();

        double vx, vy;

        double tx,ty;
        double x,y,ax,ay,b,g,c;


        b=0.01;
        c=0.001;
        g=9.81;


        while (true) {
            if(StdDraw.isMousePressed()) {
                x = 0;
                y = 0;
                T=0;
                vx = v*StdDraw.mouseX();
                vy = v*StdDraw.mouseY();
                StdDraw.setPenColor(StdDraw.GREEN);
                StdDraw.line(-0.1 * size, 0, 2*size, 0);
                StdDraw.line(0, -0.1 * size, 0, 2 * size);
                StdDraw.setPenColor(StdDraw.RED);
                StdDraw.line(0, 0, vx/v, vy/v);

                tx = x;
                ty = y;

                while (y >= 0) {
                    if(T>100000*dt) break; T+=dt;
                    StdDraw.setPenRadius(0.003);
                    StdDraw.setPenColor(StdDraw.BLUE);
                    StdDraw.line(tx, ty, x, y);
                    tx = x;
                    ty = y;
                    ax = -b * vx - c * vx * Math.sqrt(vx * vx + vy * vy);
                    ay = -b * vy - c * vy * Math.sqrt(vx * vx + vy * vy)
                            -g;
                    vx += ax * dt;
                    vy += ay * dt;
                    x += vx * dt;
                    y += vy * dt;
                }
                StdDraw.line(x - vx * dt, y - vy * dt, x-y*vx/vy, 0);
                StdDraw.show();
                StdDraw.clear(StdDraw.BLACK);
            }
        }
        /*double size = 1;
        double x = 0, y = 0, vx = 1, vy = 1, ax, ay;
        double dt = 0.001;
        double b = 0.1;
        double g = 9.81;
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(-0.1 * size, size);
        StdDraw.setYscale(-0.1 * size, size);


        StdDraw.setPenColor(StdDraw.GREEN);
        StdDraw.setPenRadius(0.004);
        StdDraw.line(-0.1 * size, 0, size, 0);
        StdDraw.line(0, -0.1 * size, 0, size);


        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.line(0, 0, vx, vy);
        for (double t = 0; y >= 0; t += dt) {
            ay = -b * y - g;
            ax = -b * x;
            vx += ax * dt;
            vy += ay * dt;
            x += vx * dt + ax * dt * dt / 2;
            y += vy * dt + ay * dt * dt / 2;
            StdDraw.setPenColor(Color.blue);
            StdDraw.setPenRadius(0.003);
            StdDraw.point(x, y);
        }
        StdDraw.show();
        */

    }
}
