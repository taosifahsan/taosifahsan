/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */

public class schrodinger {
    public static double f(double x) {
        return Math.exp(-(x-0.5)*(x-0.5)*100);
    }

    public static void main(String[] args) {
        //variable declaration
        double t, dt=0.01; int T=1000, res=10000, size=1;
        double x;
        double[] y=new double[size*res];
        double[] at=new double[size*res];
        double[] vt=new double[size*res];

        for(int i=0;i<size*res;i++)
        {
            y[i]=f((i+0.0)/res);
        }
        //size parameters
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0,size);
        StdDraw.setYscale(-size, size);
        StdDraw.setPenColor(StdDraw.RED);

        //intial condition


        //loop to evolve
        for(t=0;t<T;t+=dt) {
            //loop of evolution

            for(int i=0;i<size*res-1;i++) {
                vt[i] = 100*(y[i]-y[i+1]);
                y[i]  +=vt[i]*dt;
                StdDraw.point((i+0.0)/res,y[i]);
            }
            //loop to print


            //show the print
            StdDraw.pause(20);
            StdDraw.show();
            //clear
            StdDraw.clear();

        }

    }
}
