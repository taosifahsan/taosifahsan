/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */

public class step {
    public static double heav(double v) {
        return (((int) (((v - 1) - (v - 1) % 1.0))) >> 31) + 1;
    }


    public static double heav2(double v) {
        return (((int) (Math.floor(v))) >> 31) + 1;
    }

    public static double discreet(double x, double r) {

        return heav(x * x - r * r) * Math.pow(x, -3) * (2 * heav(x) - 1)
                + heav(r * r - x * x) * Math.pow(r, -3) * (2 * heav(r) - 1);


    }


    public static void main(String[] args) {

        int n = 10;

        double j, x = 2, ax, vx = 0;

        double t = 0.01;

        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(-5, 5);
        StdDraw.setYscale(-5, 5);

        StdDraw.setPenRadius(0.002);
        StdDraw.setPenColor(StdDraw.BLUE);


        StdDraw.enableDoubleBuffering();

        while (true) {
            ax = -discreet(x, 1.002) * x;

            vx += ax * t;
            x += vx * t + ax * t * t / 2;
            StdDraw.setPenRadius(0.03);
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.point(x, 0);
            StdDraw.setPenRadius(0.002);
            StdDraw.circle(0, 0, 1);
            StdDraw.show();
            StdDraw.clear();
        }

    }
}
