import matplotlib.pyplot as plt 
import numpy as np


fig=plt.figure(figsize=(15, 8))
ax=fig.add_subplot(111)

ax.plot([0,1],[1.5,1.5],'k')
ax.plot([1,2],[1.5,0.5],'k')
ax.plot([1,1],[0,1.5],'k--')
ax.plot([2,2],[0,0.5],'k--')
ax.text(0.3,1.55,'$E_1+E_2$',fontsize=30)
ax.text(1.9,0.4,'$E_1$',fontsize=30)
ax.text(0.9,0.05,'$t_f$',fontsize=30)
ax.text(1.9,0.05,'$t_p$',fontsize=30)
ax.grid()
ax.set_ylim(0,1.7)
ax.set_xlim(0,2)
ax.set_xlabel('time difference, $\\Delta t$',fontsize=30)
ax.set_ylabel('Apparent Energy, $E$',fontsize=30)
ax.tick_params(labelsize=20)
plt.savefig('E_vs_delta_t.pdf')
plt.show()