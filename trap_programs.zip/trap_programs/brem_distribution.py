import matplotlib.pyplot as plt
import numpy as np
from scipy import integrate
import math
import sys


#include an function defition where we call an array and return an array for real life data

def v(x):
    return math.sqrt(abs(x))*(x>0)



def gaunt(v1,v2):

    if v2==0:
        return 0
    if v1>v2:
        return (v1/v2)*(1-np.e**(-2*np.pi/v1))/(1-np.e**(-2*np.pi/v2))*np.log((v1+v2)/(v1-v2))
    else:
       return 0


font = {'fontname':'Times'}

#range and accuracy
start=0.01
end=5
N=200

#probablity of overlap
utf=0.1

#incidence distribution, change at will

E0=end*0.4
b=0.1

f = lambda E: gaunt(v(E0)/b,v(E0-E)/b)/E*(E0-1/N>E)*(E>1/N)

#normalizing the distribution
norm = integrate.quad(lambda x: f(x),0.0000001,E0-0.000001)[0]
fI = lambda E : f(E)/norm

#integrals
fA = lambda E : integrate.quad(lambda x: fI(x)*fI(E-x),0,E)[0]
fB = lambda E : integrate.dblquad(lambda y, x: fI(x)*fI(y)/y, E/2, E, lambda x: E-x, lambda x: x)[0]
fC = lambda E : fI(E)*(integrate.quad(lambda x: fI(x),0,E)[0])

E=np.linspace(start,end,N)

I=[]
A=[]
B=[]
C=[]

for i in range(len(E)):
    	I = np.append(I, fI(E[i]))
    	A = np.append(A, fA(E[i]))
    	B = np.append(B, fB(E[i]))
    	C = np.append(C, fC(E[i]))

#plotting using the general rule of fi *P(1) + P(2)*((1-a)*A+a*B+a*C)) where for
# low value of u*tf, p(1)=1-utf, p(2)=utf upto one order of magnitude

#plot for linear graph. Enter lin in terminal after .py to execute
if(sys.argv[1]=='lin'):
    for a in [0.0, 0.25, 0.50, 0.75, 1.00]:
        plt.plot(E,(1-utf)*I+utf*((1-a)*A+a*(B+C)), label='a='+str(a))
    plt.xlabel('Energy', **font)
    plt.ylabel('probablity distribution', **font)

#plot for logarithmic graph. Enter log in terminal after .py to execute
elif(sys.argv[1]=='log'):
    for a in [0.0, 0.25, 0.50, 0.75, 1.00]:
        plt.plot(E,np.log((1-utf)*I+utf*((1-a)*A+a*(B+C)))/np.log(10), label='a='+str(a))
    plt.xlabel('Energy', **font)
    plt.ylabel('log(probablity distribution)', **font)

#plot for double logarithmic graph. Enter dblog in terminal after .py to execute
elif(sys.argv[1]=='dblog'):
    for a in [0.0, 0.25, 0.50, 0.75, 1.00]:
        plt.plot(np.log(E)/np.log(10),(1-utf)*I+utf*((1-a)*A+a*(B+C)), label='a='+str(a))
    plt.xlabel('log(Energy)', **font)
    plt.ylabel('log(probablity distribution)', **font)

#plot for double logarithmic graph. Enter ABC in terminal after .py to execute
elif(sys.argv[1]=='ABC'):
    plt.plot(E, I, label='Original')
    plt.plot(E,A,label='Integral A')
    plt.plot(E,B,label='Integral B')
    plt.plot(E,C,label='Integral C')
    plt.xlabel('Energy', **font)
    plt.ylabel('probablity distribution', **font)

else:
    plt.xlabel('Energy', **font)
    plt.ylabel('probablity distribution', **font)


plt.title('Overlap probablity=0.1', **font)
plt.legend()
plt.grid()
plt.show()
