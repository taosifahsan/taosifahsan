import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from scipy import integrate
import math
import sys
def v(x):
   return math.sqrt(abs(x))*(x>0)
   
def gaunt(v1,v2):

    if v2==0:
        return 0
    if v1>v2:
        return (v1/v2)*(1-np.e**(-2*np.pi/v1))/(1-np.e**(-2*np.pi/v2))*np.log((v1+v2)/(v1-v2))
    else:
       return 0

#the function
b=0.1
E0=2
fI=lambda E: gaunt(v(E0)/b,v(E0-E)/b)/E*(E0-1/100>E)*(E>1/100)


font = {'fontname':'Times'}

#overlap probablity
utf=0.1


start=0
end=5
accuracy=100
N=int(sys.argv[1])

x_axis=np.linspace(1/accuracy+start,end,accuracy)

#normalizing the function
norm=0
for x in x_axis:
	norm+=fI(x)*(end-start)/accuracy

f=lambda x: fI(x)/norm


#initiating the arrays
I=[]
A=[]
B=[]
C=[]

#monte carlo simulation starts

for a in x_axis:
	I=np.append(I,f(a))

for a in x_axis:
	sum=0
	for i in range(N):
		x=random.uniform(0,a)
		if(x<a):
			sum+=f(x)*f(a-x)
	A=np.append(A,sum*a/N)
		
for a in x_axis:
	sum=0
	for i in range(N):

    		x=random.uniform(a/2,a)
    		y=random.uniform(0,a)

   		#plt.plot(x,y,'ro',marker=".", markersize=1)
    		if((x>y) and (x+y>a)) and (a>x):
        		sum+=f(x)*f(y)/y

	B=np.append(B,sum*(a**2/2/N))


for a in x_axis:
	sum=0
	for i in range(N):
		x=random.uniform(0,a)
		if(x<a):
			sum+=f(x)
	C=np.append(C,f(a)*sum*a/N)



#plotting the graphs
if(sys.argv[2]=='lin'):
	for m in [0.0, 0.25, 0.50, 0.75, 1.00]:
		plt.plot(x_axis,I*(1-utf)+utf*((1-m)*A+m*B+m*C),linewidth=1, label='a='+str(m))
	plt.xlabel('Energy', **font)
	plt.ylabel('probablity distribution', **font)

if(sys.argv[2]=='log'):
	for m in [0.0, 0.25, 0.50, 0.75, 1.00]:
		plt.plot(x_axis,np.log(I*(1-utf)+utf*((1-m)*A+m*B+m*C))/np.log(10),linewidth=1, label='a='+str(m))
	plt.xlabel('Energy', **font)
	plt.ylabel('log(probablity distribution)', **font)

plt.title('Overlap probablity=0.1', **font)
plt.legend()
plt.grid()
plt.show()
