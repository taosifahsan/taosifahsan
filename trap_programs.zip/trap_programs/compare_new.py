import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from scipy import integrate
import math
import sys
import csv
#python3.8 compare_abs.py 1000 plot o 0.5


avoid=10E-14
level=10E-12
#turning array into function
def func(y_arr,x_arr,x):
	size=len(y_arr)
	i=int(round(x*size/x_arr[size-1]))
	if i<size:
		return y_arr[i]
	else: 
		return 0


def zero_to_nan(values):
    return [float('nan') if x<=level else x for x in values]

#reading array
title_31='31-14kcps.csv'
title_27='27-62kcps.csv'
x=[]
y_31=[]
y_27=[]
with open(title_31, 'r') as file:
	read = csv.reader(file, delimiter=' ')
	for column in read:
		y_31.append(float(column[0]))

with open(title_27, 'r') as file:
	read = csv.reader(file, delimiter=' ')
	for column in read:
		y_27.append(float(column[0]))

t_r=200*10**(-9)
t_f=(200+12+200)*10**(-9)
t_e=12*10**(-9)
trngl_ness=1-t_e/t_f

total_count_31=np.sum(y_31)
acc_time_31=61.578000
count_rate_31=total_count_31/acc_time_31

total_count_27=np.sum(y_27)
acc_time_27=113.511000
count_rate_27=total_count_27/acc_time_27

utf_27=count_rate_27*t_f

for i in range(len(y_31)):
	y_31[i]=y_31[i]/acc_time_31
	y_27[i]=y_27[i]/acc_time_27

lin=np.linspace(1,len(y_27),len(y_27))
M=8.8014
B=-25.2794
x=M*lin+B

start=x[0]
end=x[len(x)-1]
accuracy=len(x)

N=int(sys.argv[1])

#the function
fI_31=lambda E: func(y_31,x,E)#*(5100>E)
fI_27=lambda E: func(y_27,x,E)

#normalizing the function
norm_31=0
norm_27=0
for E in x:
	norm_31+=fI_31(E)*(end-start)/accuracy
	norm_27+=fI_27(E)*(end-start)/accuracy

f_31=lambda E: fI_31(E)/norm_31
f_27=lambda E: fI_27(E)/norm_27

#initiating the arrays
I_31=[]
A_31=[]
B_31=[]
C_31=[]
D_31=[]


I_27=[]

x_axis=np.linspace(start,end,accuracy)

#monte carlo simulation starts
for a in x_axis:
	I_31 = np.append(I_31,f_31(a))
	I_27 = np.append(I_27, f_27(a))

for a in x_axis:
	sum_31=0
	E_x=np.linspace(0,a,int(np.sqrt(N)))
	dE_x=E_x[1]-E_x[0]
	for i in range(len(E_x)):
		length_y=int(np.sqrt(N))
		E_y=np.linspace(a-E_x[i]+avoid,x_axis[len(x_axis)-1],length_y)
		dE_y=E_y[1]-E_y[0]
		for j in range(len(E_y)):
			term=f_31(E_x[i])*f_31(E_y[j])/E_y[j]*dE_y*dE_x
			sum_31+=term
	D_31=np.append(D_31,sum_31)

for a in x_axis:
	sum_31=0
	E=np.linspace(0,a,N)
	for i in range(N):
		sum_31+=f_31(E[i])*f_31(a-E[i])
	A_31=np.append(A_31,sum_31*a/N)

for a in x_axis:

	sum_31=0
	E_x=np.linspace(a/2,a,int(np.sqrt(N)))
	for i in range(len(E_x)):
		length_y=int(2*np.sqrt(N)*(2*E_x[i]-a)/a)
		E_y=np.linspace(a-E_x[i]+avoid,E_x[i]-avoid,length_y)
		for j in range(len(E_y)):
			term=f_31(E_x[i])*f_31(E_y[j])/E_y[j]
			sum_31+=term

	B_31=np.append(B_31,sum_31*(a**2/2)/len(E_x)/len(E_y))

for a in x_axis:

	sum_31=0
	E_x=np.linspace(0,a,N)
	for i in range(N):
		sum_31+=f_31(E_x[i])
	C_31=np.append(C_31,f_31(a)*sum_31*a/N)

factor=count_rate_27/count_rate_31

#plotting the graphs
font = {'fontname' : 'Times',
		'size'	   : 30}

plot_A=[]
plot_B=[]
plot_C=[]
plot_D=[]
for i in range(len(I_31)):
	plot_A=np.append(plot_A,A_31[i])
	plot_B=np.append(plot_B,B_31[i])
	plot_C=np.append(plot_C,C_31[i])
	plot_D=np.append(plot_D,D_31[i])



shape="-"
mark=1
figure= plt.figure(figsize=(15, 9))
ax=figure.add_subplot(111)
ax.semilogy(x_axis,count_rate_27*t_e*A_31)
ax.semilogy(x_axis,count_rate_27*t_r*C_31)
ax.semilogy(x_axis,count_rate_27*2*t_r*B_31)
ax.semilogy(x_axis,count_rate_27*t_r*D_31)
ax.semilogy(x_axis,I_31)

'''
plot1=np.maximum(norm_27*I_27,1E-4)
plot5=np.maximum(norm_31*plot*factor,1E-4)
ax.semilogy(x_axis,plot1,
	linewidth=mark, color='blue',
	label='high count rate=65kcps')
ax.semilogy(x_axis,plot5,
	linewidth=mark, color='red',
	label='Matched data\npiled up using\ntrapezoid model')
'''

ax.set_xlabel('Energy (eV)',fontsize=30)#, **font)
ax.set_ylabel('Count rate per energy bin\n(count/s/eV)',fontsize=30)


ax.grid(True, which="both", ls="-.")
plt.xticks(fontsize= 25)
plt.yticks(fontsize= 25)

plt.show()
