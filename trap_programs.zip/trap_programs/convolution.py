import matplotlib.pyplot as plt
import numpy as np
from scipy import integrate
import math
import sys
import csv

def mov_avg(y, w):
	y_smooth=y
	for i in range(len(y)-len(w)):
		y_smooth[i+int(len(w)/2)]=sum(y[i:i+len(w):]*w)/sum(w)
	return y_smooth

def plot(y,bar,w):
	return np.maximum(mov_avg(np.array(y), w),bar)

#convolution method
def conv(E,F,V):
	N=len(E)
	dE=(max(E)-min(E))/N
	I=np.linspace(0,0,N)
	for n in range(N):
		for m in range(n):
			I[n]+=F[m]*V[n-m]*dE
		I[n]-=(F[0]*V[n]+F[n]*V[0])/2*dE
	return I

#poisson distribution
def pois(n,T):
	return np.e**(-T)*(T**n)/math.factorial(n)

#range and accuracy
start=0.00
end=8000
#number of terms in series
term_N=2
#probablity of overlap
utf=0.0267
term_N+=1
title_31='31-14kcps.csv'
F=[]
with open(title_31, 'r') as file:
	read = csv.reader(file, delimiter=' ')
	for column in read:
		F.append(float(column[0]))

F=np.array(F)*65/14
lin=np.linspace(1,len(F),len(F))
M=8.8014
B=-25.2794
E=M*lin+B
N=len(E)
bar=2e-1
w=[0.1,0.3,0.5,0.8,1,0.8,0.5,0.3,0.1]

'''
#incidence distribution, change at will
s=0.0005
E1=0.07
E2=0.11
E3=0.3
E0=0.2
A=10**5
bar=2e-2
s=0.01
C=0.5
F1 = A*np.exp(-(E-(E1*end))**2/(s*end)**2)/((s*end)*np.sqrt(np.pi))
F2 = A*np.exp(-(E-(E2*end))**2/(s*end)**2)/((s*end)*np.sqrt(np.pi))
F3 = A/4*np.exp(-(E-(E3*end))**2/(s*end)**2)/((s*end)*np.sqrt(np.pi))
F5 = A/2000*(1200<=E)*(E<=2000)
F4= A/1000*(5000-E)/(5000)*(E<=5000)*(E>=450)
F=(F1+F2+F3+F4+F5)
'''
dE=(max(E)-min(E))/len(E)
u=sum(F)*dE-((F[0]+F[N-1])/2)*dE
cr=sum(F)/65
tf=utf/cr
F=F/u
I=[np.linspace(0,0,N)]*term_N
I[0]=F

#convolution 
for i in range(term_N-1):
	I[i+1] = conv(E,I[i],I[0])

#adding all convoluted terms
spectra=np.linspace(0,0,N)
for i in range(term_N-1):
	spectra+=I[i]*pois(i, utf)

figure= plt.figure()
ax=figure.add_subplot(111)
plot_spectra=np.maximum(u*spectra,bar)
plot_raw=np.maximum(u*F,bar)
ax.semilogy(E,plot(plot_raw,bar,w),label='Raw Spectrum')
ax.semilogy(E,plot(plot_spectra,bar,w),label='Piled-up via\nConvolution')

handles,labels = ax.get_legend_handles_labels()

ax.legend(loc='best',fontsize= 25)

ax.set_xlabel('Energy (eV)',fontsize=30)
ax.set_ylabel('Count rate per energy bin\n(count/s/eV)',fontsize=30)
plt.title('$\\mu=$'+'{:.1e}'.format(u)+'cps,  '+'$t_f=$'+'{:.2e}'.format(tf)+'s\n',fontsize=30)
plt.xticks(fontsize= 25)
plt.yticks(fontsize= 25)
ax.grid(True, which="both", ls="-.")
plt.savefig('convolution.pdf')
plt.show()

