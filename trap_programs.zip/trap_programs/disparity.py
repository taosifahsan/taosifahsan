import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from scipy import integrate
import math
import sys
import csv

def mov_avg(y, w):
	y_smooth=y
	for i in range(len(y)-len(w)):
		y_smooth[i+int(len(w)/2)]=sum(y[i:i+len(w):]*w)/sum(w)
	return y_smooth

def plot(y,bar,w):
	return np.maximum(mov_avg(np.array(y), w),bar)

#python3.8 compare_abs.py 1000 plot o 0.5


avoid=10E-14
level=10E-12
#turning array into function
def func(y_arr,x_arr,x):
	size=len(y_arr)
	i=int(round(x*size/x_arr[size-1]))
	if i<size:
		return y_arr[i]
	else: 
		return 0


def zero_to_nan(values):
    return [float('nan') if x<=level else x for x in values]

#reading array
title_31='31-14kcps.csv'
title_27='27-62kcps.csv'
x=[]
y_31=[]
y_27=[]
with open(title_31, 'r') as file:
	read = csv.reader(file, delimiter=' ')
	for column in read:
		y_31.append(float(column[0]))

with open(title_27, 'r') as file:
	read = csv.reader(file, delimiter=' ')
	for column in read:
		y_27.append(float(column[0]))

time=412
t_f=(time)*10**(-9)


total_count_31=np.sum(y_31)
acc_time_31=61.578000
count_rate_31=total_count_31/acc_time_31

total_count_27=np.sum(y_27)
acc_time_27=113.511000
count_rate_27=total_count_27/acc_time_27

utf_27=count_rate_27*t_f

for i in range(len(y_31)):
	y_31[i]=y_31[i]/acc_time_31
	y_27[i]=y_27[i]/acc_time_27

lin=np.linspace(1,len(y_27),len(y_27))
M=8.8014
B=-25.2794
x=M*lin+B

start=x[0]
end=x[len(x)-1]
accuracy=len(x)

N=int(sys.argv[1])

#the function
fI_31=lambda E: func(y_31,x,E)#*(5100>E)
fI_27=lambda E: func(y_27,x,E)

#normalizing the function
norm_31=0
norm_27=0
for E in x:
	norm_31+=fI_31(E)*(end-start)/accuracy
	norm_27+=fI_27(E)*(end-start)/accuracy

f_31=lambda E: fI_31(E)/norm_31
f_27=lambda E: fI_27(E)/norm_27

#initiating the arrays
I_31=[]
A_31=[]

I_27=[]

x_axis=np.linspace(start,end,accuracy)

#monte carlo simulation starts
for a in x_axis:
	I_31 = np.append(I_31,f_31(a))
	I_27 = np.append(I_27, f_27(a))

for a in x_axis:
	sum_31=0
	E=np.linspace(0,a,N)
	for i in range(N):
		sum_31+=f_31(E[i])*f_31(a-E[i])
	A_31=np.append(A_31,sum_31*a/N)

factor=count_rate_27/count_rate_31

#plotting the graphs
font = {'fontname' : 'Times',
		'size'	   : 30}

plot_prev=[]
plot_prev_2=[]
plot_prev_1by4=[]


for i in range(len(I_31)):
	plot_prev=np.append(plot_prev,I_31[i]*(1-utf_27)+utf_27*A_31[i])
	plot_prev_2=np.append(plot_prev_2,I_31[i]*(1-utf_27*2)+2*utf_27*A_31[i])
	plot_prev_1by4=np.append(plot_prev_1by4,I_31[i]*(1-utf_27/4)+utf_27/4*A_31[i])

shape="-"
mark=1
figure= plt.figure(figsize=(15, 9))
ax=figure.add_subplot(111)

plot1=norm_27*I_27
plot2=norm_31*I_31
plot3=norm_31*I_31*factor
plot4=norm_31*plot_prev*factor
plot5=norm_31*plot_prev_2*factor
plot6=norm_31*plot_prev_1by4*factor

dE=(x_axis[1]-x_axis[0])

print(sum(plot1))
print(sum(plot4))
print(sum(plot6))
print(sum(plot5))

bar=3e-3
w=[0.1,0.3,0.5,0.8,1,0.8,0.5,0.3,0.1]
ax.semilogy(x_axis,plot(plot1,bar,w),
	linewidth=mark*2, color='blue',
	label='high count rate=65kcps')
#ax.semilogy(x_axis,plot(plot3,bar,w), 
	#linewidth=mark, color='green',
	#label='14 kcps data\nmultiplied by 65/14\nto match 65kcps')
#ax.semilogy(x_axis,plot(plot2,bar,w),
	#linewidth=mark, color='orange',
	#label='low count rate=14kcps')
ax.semilogy(x_axis,plot(plot4,bar,w),
	linewidth=mark*2, color='purple',
	label='piled up using\nrectangular model\nfilter time=412 ns (real),')
ax.semilogy(x_axis,plot(plot6,bar,w),
	linewidth=mark*2, color='grey',
	label='filter time=103 ns')
ax.semilogy(x_axis,plot(plot5,bar,w),
	linewidth=mark*2, color='black',
	label='filter time=824 ns')


ax.set_xlabel('Energy (eV)',fontsize=30)
ax.set_ylabel('Count rate per energy bin\n(count/s/eV)',fontsize=30)

#handles,labels = ax.get_legend_handles_labels()
#handles = [handles[0], handles[2], handles[1],handles[3]]
#labels = [labels[0], labels[2], labels[1],labels[3]]
ax.legend(loc='best',fontsize= 25)

ax.grid(True, which="both", ls="-.")
plt.xticks(fontsize= 25)
plt.yticks(fontsize= 25)

plt.savefig('disparity_log_scale_000.pdf')
plt.show()
