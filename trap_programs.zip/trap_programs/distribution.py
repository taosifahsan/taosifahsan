import matplotlib.pyplot as plt
import numpy as np
from scipy import integrate
import math
import sys


#include an function defition where we call an array and return an array for real life data

font = {'fontname':'Times',
        'size'    :30}

e=2.7182818284
pi=3.14159265
E0=1
#range and accuracy
start=0.005
end=2.5
N=400

#probablity of overlap
utf=0.1
#incidence distribution, change at will
f = lambda E: (np.exp(-(E-1)**2/0.001))

#normalizing the distribution
norm = integrate.quad(lambda x: f(x),0,1.5)[0]
fI = lambda E : f(E)/norm

#integrals
fA = lambda E : integrate.quad(lambda x: fI(x)*fI(E-x),0,E)[0]
fB = lambda E : integrate.dblquad(lambda y, x: fI(x)*fI(y)/y, 0, E, lambda x: E-x, lambda x: end)[0]


E=np.linspace(start,end,N)

I=[]
A=[]
B=[]


#creating arrays from defined integral
for i in range(len(E)):
    	I = np.append(I, fI(E[i]))
    	A = np.append(A, fA(E[i]))
    	B = np.append(B, fB(E[i]))

#plotting using the general rule of fi *P(1) + P(2)*((1-a)*A+a*B+a*C)) where for
# low value of u*tf, p(1)=1-utf, p(2)=utf upto one order of magnitude
figure= plt.figure(figsize=(15, 8.5))
ax=figure.add_subplot(111)
#plot for linear graph. Enter lin in terminal after .py to execute

for a in [0.0, 0.25, 0.50, 0.75, 1.00]:
    plt.semilogy(E,(1-utf)*I+utf*((1-a)*A+a*B), linewidth=3, label='a='+str(a))
ax.set_xlabel('Energy (keV)',fontsize=30)#, **font)
ax.set_ylabel('probablity distribution',fontsize=30)#, **font)
ax.set_xlim(0.9,2.1)
ax.set_ylim(1E-3,20)

data_list=[None]*6
data_list[0]=E
i=1
for a in [0.0, 0.25, 0.50, 0.75, 1.00]:
	data_list[i]=(1-utf)*I+utf*((1-a)*A+a*B)
	i=i+1

dat = np.array(data_list)
dat = dat.T
np.savetxt('monochromatic_trap_model.txt', dat, delimiter = ',  ')

plt.title('Overlap probablity = 0.1',fontsize=30)# **font)#, FWHM=0.0738
plt.xticks(fontsize= 25)#, **font)
plt.yticks(fontsize= 25)#, **font)
ax.legend(loc='best',fontsize= 25)
ax.grid(True, which="both", ls="-.")
plt.savefig('dirac_delta_log.pdf')
plt.show()


