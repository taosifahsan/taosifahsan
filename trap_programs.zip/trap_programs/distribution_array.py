import matplotlib.pyplot as plt
import numpy as np
from scipy import integrate
import math
import sys
import csv

#include an function defition where we call an array and return an array for real life data
def func(I, x, a):
    i = round(a * len(I) / x[len(I) - 1])
    N = len(I)

    if i < N:
        return I[round(a * len(I) / x[len(I) - 1])]
    else:
        return 0

title='brem_elwart.csv'
x=[]
y=[]
with open(title, 'r') as file:
	read = csv.reader(file, delimiter=',')
	for column in read:
		x.append(float(column[0]))
		y.append(float(column[1]))

font = {'fontname':'Times'}

e=np.e
pi=np.pi

#range and accuracy

N =len(x)
start=x[0]
end=x[N-1]


#probablity of overlap
utf=0.1

#incidence distribution, change at will

f = lambda E: func(y,x,E)

#normalizing the distribution
norm = integrate.quad(lambda x: f(x),start,end)[0]

fI = lambda E : f(E)/norm

#integrals
fA = lambda E : integrate.quad(lambda x: fI(x)*fI(E-x),0,E)[0]
fB = lambda E : integrate.dblquad(lambda y, x: fI(x)*fI(y)/y, E/2, E, lambda x: E-x, lambda x: x)[0]
fC = lambda E : fI(E)*(integrate.quad(lambda x: fI(x),0,E)[0])

E=np.linspace(start,end*2,N*2)

I=[]
A=[]
B=[]
C=[]

#creating arrays from defined integral
for i in range(len(E)):
    	I = np.append(I, fI(E[i]))
    	A = np.append(A, fA(E[i]))
    	B = np.append(B, fB(E[i]))
    	C = np.append(C, fC(E[i]))

#plotting using the general rule of fi *P(1) + P(2)*((1-a)*A+a*B+a*C)) where for
# low value of u*tf, p(1)=1-utf, p(2)=utf upto one order of magnitude

#plot for linear graph. Enter lin in terminal after .py to execute
if(sys.argv[1]=='lin'):
    for a in [0.0, 0.25, 0.50, 0.75, 1.00]:
        plt.plot(E,(1-utf)*I+utf*((1-a)*A+a*(B+C)), label='a='+str(a))
    plt.xlabel('Energy', **font)
    plt.ylabel('probablity distribution', **font)

#plot for logarithmic graph. Enter log in terminal after .py to execute
elif(sys.argv[1]=='log'):
    for a in [0.0, 0.25, 0.50, 0.75, 1.00]:
        plt.plot(E,np.log((1-utf)*I+utf*((1-a)*A+a*(B+C)))/np.log(10), label='a='+str(a))
    plt.xlabel('Energy', **font)
    plt.ylabel('log(probablity distribution)', **font)

#plot for double logarithmic graph. Enter dblog in terminal after .py to execute
elif(sys.argv[1]=='dblog'):
    for a in [0.0, 0.25, 0.50, 0.75, 1.00]:
        plt.plot(np.log(E)/np.log(10),(1-utf)*I+utf*((1-a)*A+a*(B+C)), label='a='+str(a))
    plt.xlabel('log(Energy)', **font)
    plt.ylabel('log(probablity distribution)', **font)

#plot for double logarithmic graph. Enter ABC in terminal after .py to execute
elif(sys.argv[1]=='ABC'):
    plt.plot(E, I, label='Original')
    plt.plot(E,A,label='Integral A')
    plt.plot(E,B,label='Integral B')
    plt.plot(E,C,label='Integral C')
    plt.xlabel('Energy', **font)
    plt.ylabel('probablity distribution', **font)

else:
    plt.xlabel('Energy', **font)
    plt.ylabel('probablity distribution', **font)
plt.title('Overlap probablity=0.1', **font)
plt.legend()
plt.grid()
plt.show()


