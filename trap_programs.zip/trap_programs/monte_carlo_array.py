import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from scipy import integrate
import math
import sys
import csv


#turning array into function
def func(I,x,a):
	i=round(a*len(I)/x[len(I)-1])
	N=len(I)
	
	if i<N:
		return I[int(round(a*len(I)/x[len(I)-1]))]
	else:
		return 0
	



#reading array
title='brem_elwart.csv'
x=[]
y=[]
with open(title, 'r') as file:
	read = csv.reader(file, delimiter=',')
	for column in read:
		x.append(float(column[0]))
		y.append(float(column[1]))



#overlap probablity
utf=0.1

start=x[0]
end=x[len(x)-1]
accuracy=len(x)
N=int(sys.argv[1])


#the function
fI=lambda E: func(y,x,E)

#normalizing the function
norm=0
for E in x:
	norm+=fI(E)*(end-start)/accuracy

f=lambda E: fI(E)/norm


#initiating the arrays
I=[]
A=[]
B=[]
C=[]

x_axis=np.linspace(start,end*2,accuracy*2)

#monte carlo simulation starts
for a in x_axis:
	I=np.append(I,f(a))

for a in x_axis:
	sum=0
	for i in range(N):
		E=random.uniform(0,a)
		if(E<a):
			sum+=f(E)*f(a-E)
	A=np.append(A,sum*a/N)
		
for a in x_axis:
	sum=0
	for i in range(N):

    		E_x=random.uniform(a/2,a)
    		E_y=random.uniform(0,a)

    		if((E_x>E_y) and (E_x+E_y>a)) and (a>E_x):
        		sum+=f(E_x)*f(E_y)/E_y

	B=np.append(B,sum*(a**2/2/N))

for a in x_axis:
	sum=0
	for i in range(N):
		E_x=random.uniform(0,a)
		if(E_x<a):
			sum+=f(E_x)
	C=np.append(C,f(a)*sum*a/N)



#plotting the graphs

font = {'fontname':'Times'}
plt.xlabel('Energy (ev)', **font)

if(sys.argv[2]=='lin'):
	for m in [0.0, 0.25, 0.50, 0.75, 1.00]:
		plot=[]
		for i in range(len(I)): 
			plot=np.append(plot,I[i]*(1-utf)+utf*((1-m)*A[i]+m*B[i]+m*C[i]))

		plt.plot(x_axis,plot,linewidth=1, label='a='+str(m))
	plt.ylabel('probablity distribution', **font)

if(sys.argv[2]=='log'):
	for m in [0.0, 0.25, 0.50, 0.75, 1.00]:
		plot=[]
		for i in range(len(I)): 
			plot=np.append(plot,I[i]*(1-utf)+utf*((1-m)*A[i]+m*B[i]+m*C[i]))

		plt.plot(x_axis,np.log(plot)/np.log(10),linewidth=1, label='a='+str(m))
	plt.ylabel('log(probablity distribution)', **font)

plt.title('Elwert Model', **font)
plt.legend()
plt.grid(True, which="both", ls="-")
plt.show()
