import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from scipy import integrate
import math
import sys
import csv

def accum(title):
	if title=='31-14kcps':
		return 61.578000
	if title=='30-23kcps':
		return 85.795000
	if title=='29-34kcps':
		return 59.579000
	if title=='28-50kcps':
		return 59.187000
	if title=='27-62kcps':
		return 113.511000
	else:
		return 113.511000

title=sys.argv[1]
acc_time=accum(title)
x=[]
y=[]

with open(title, 'r') as file:
	read = csv.reader(file, delimiter=' ')
	for column in read:
		y.append(float(column[0])/acc_time)

total_count=np.sum(y)
count_rate=total_count/acc_time
t_f=(200+12+200)
t_e=12
trngl_ness=1-t_e/t_f
utf=count_rate*t_f*10**(-9)

lin=np.linspace(1,len(y),len(y))

M=8.8014
B=-25.2794
x=M*lin+B

font = {'fontname':'Times'}
plt.semilogy(x,y,linewidth=1)
plt.xlabel('Energy (ev)', **font)
plt.ylabel('count rate per energy bin (count/s/eV)', **font)

plt.title(title+', p(1)='+str('{:.2E}'.format(utf)), **font)
plt.legend()
plt.grid()
plt.show()
