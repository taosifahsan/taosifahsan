import matplotlib.pyplot as plt 
import numpy as np


fig=plt.figure(figsize=(15, 8))
ax=[None]*4
ax[0]=fig.add_subplot(221)
ax[1]=fig.add_subplot(222)
ax[2]=fig.add_subplot(223)
ax[3]=fig.add_subplot(224)

font = {'fontname' : 'Times',
		'size'	   : 25}

x=np.linspace(0,6,1000)

fact=0.5
dist=1.25
sig=1

f=[None]*4
f[0]=(1<x)*(x<4)
f[1]=(1<=x)*(x<2.5)*(x-1)/1.5+(2.5<=x)*(x<=4)*(4-x)/1.5
f[2]=(1<=x)*(x<2)*(x-1)+(2<=x)*(x<=3)+(3<x)*(x<=4)*(4-x)
f[3]=np.exp(-(x-2.5)**2/sig**2)



x1=x-dist
g=[None]*4
g[0]=(1<x1)*(x1<4)*fact
g[1]=((1<=x1)*(x1<2.5)*(x1-1)/1.5+(2.5<=x1)*(x1<=4)*(4-x1)/1.5)*fact
g[2]=((1<=x1)*(x1<2)*(x1-1)+(2<=x1)*(x1<=3)+(3<x1)*(x1<=4)*(4-x1))*fact
g[3]=np.exp(-(x1-2.5)**2/sig**2)*fact



for i in range(4):
	ax[i].plot(x,f[i])
	ax[i].plot(x,g[i])
	ax[i].plot(x,f[i]+g[i])
	ax[i].grid()
	ax[i].set_ylim(0,1.6)
	ax[i].set_xlabel('time, t',fontsize=25)# **font)
	ax[i].set_ylabel('voltage, V(t)',fontsize=25)# **font)
	ax[i].tick_params(labelsize=15)



ax[0].set_title('Rectangular pulse',fontsize=25)# **font)
ax[1].set_title('Triangular pulse',fontsize=25)# **font)
ax[2].set_title('Trapezoidal pulse',fontsize=25)# **font)
ax[3].set_title('Gaussian pulse',fontsize=25)# **font)

fig.subplots_adjust(hspace=0.45)
plt.savefig('plotaddition.pdf')
plt.show()