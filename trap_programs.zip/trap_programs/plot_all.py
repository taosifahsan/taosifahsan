import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from scipy import integrate
import math
import sys
import csv

def mov_avg(y, w):
	y_smooth=y
	for i in range(len(y)-len(w)):
		y_smooth[i+int(len(w)/2)]=sum(y[i:i+len(w):]*w)/sum(w)
	return y_smooth

def accum(title):
	if title=='31-14kcps.csv':
		return 61.578000
	if title=='30-23kcps.csv':
		return 85.795000
	if title=='29-34kcps.csv':
		return 59.579000
	if title=='28-50kcps.csv':
		return 59.187000
	if title=='27-62kcps.csv':
		return 113.511000
	else:
		return 113.511000

def color(title):
	if title=='31-14kcps.csv':
		return 'orange'
	if title=='30-23kcps.csv':
		return 'deeppink'
	if title=='29-34kcps.csv':
		return 'lime'
	if title=='28-50kcps.csv':
		return 'aqua'
	if title=='27-62kcps.csv':
		return 'blue'
	else:
		return 'black'

def fade_color(title):
	if title=='31-14kcps.csv':
		return (1,165.0/255.0,0,0.3)
	if title=='30-23kcps.csv':
		return 'deeppink'
	if title=='29-34kcps.csv':
		return (32/255,205/255,32/255,0.3)
	if title=='28-50kcps.csv':
		return 'aqua'
	if title=='27-62kcps.csv':
		return (0,0,1,0.3)
	else:
		return 'black'

title=['31-14kcps.csv','30-23kcps.csv','29-34kcps.csv','28-50kcps.csv','27-62kcps.csv']
x=[]
y=[None]*len(title)
count_rate=[0]*len(title)
for i in range(len(title)):
	y[i]=[]
	with open(title[i], 'r') as file:
		read = csv.reader(file, delimiter=' ')
		for column in read:
			y[i].append(float(column[0]))
	total_count=np.sum(y[i])
	acc_time=accum(title[i])
	count_rate[i]=total_count/acc_time

lin=np.linspace(1,len(y[0]),len(y[0]))

M=8.8014
B=-25.2794
x=M*lin+B

figure= plt.figure(figsize=(15, 9))
ax=figure.add_subplot(111)
mark=1
bar=3e-3
bin_k=1
z=np.linspace(1, 30)
w=[0.1, 0.3, 0.5, 0.8 ,1, 0.8,0.5,0.3,0.1]

x_min=5150
x_max=9000
bin_x_start=int(x_min/max(x)*len(x))
bin_x_end=int(x_max/max(x)*len(x))
tail_y=[None]*len(title)
E_0=[0]*len(title)
sig_E_0=[0]*len(title)
CR_tail=[0]*len(title)
sig_CR_tail=[0]*len(title)
for i in range(len(title)):
	tail_y[i]=y[i][bin_x_start:bin_x_end:]
tail_x=x[bin_x_start:bin_x_end:]

for j in range(len(title)):
	i=len(title)-j-1
	plot_rate=np.array(y[i])/accum(title[i])
	plot_bar=np.maximum(plot_rate,bar)
	plot_smooth=mov_avg(plot_rate, w)
	plot_smooth_bar=np.maximum(plot_smooth,bar)
	ax.semilogy(x,plot_smooth_bar,color=color(title[i]),
		label="Count rate="+str(int(round(count_rate[i]/1E3)))+"kcps")
	#ax.semilogy(x,plot_bar,color=fade_color(title[i]))


for i in range(len(title)):
	E_0[i]=np.sum((tail_x-x_min)*tail_y[i])/np.sum(tail_y[i])
	CR_tail[i]=np.sum(tail_y[i])/accum(title[i])
	sig_E_0[i]=E_0[i]/np.sqrt(np.sum(tail_y))
	sig_CR_tail[i]=np.sqrt(np.sum(tail_y[i]))/accum(title[i])
for j in range(len(title)):
	i=len(title)-j-1
	plot=np.maximum(y[i],accum(title[i])*bar)
	plot_tail=np.maximum(tail_y[i],accum(title[i])*bar)
	ax.semilogy(tail_x, np.maximum(CR_tail[i]/E_0[i]*np.exp((x_min-tail_x)/E_0[i])*(x_max-x_min)/len(tail_x),bar),
		'r--',linewidth=mark*2)


ax.set_xlabel('Energy (eV)',fontsize=30)
ax.set_ylabel('Count rate per energy bin\n(count/s/eV)',fontsize=30)
ax.legend(loc='best',fontsize= 20)

ax.grid(True, which="both", ls="-.")
plt.xticks(fontsize= 25)
plt.yticks(fontsize= 25)
plt.title("Filter time= 412 ns\nFaded plot: Raw Data, Bold plot: Moving Average Filtered Data", fontsize=30)
plt.savefig('raw_data_X_ray_tube.pdf')
plt.show()
