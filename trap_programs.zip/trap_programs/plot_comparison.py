import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from scipy import integrate
import math
import sys
import csv

def mov_avg(y, w):
	y_smooth=y
	for i in range(len(y)-len(w)):
		y_smooth[i+int(len(w)/2)]=sum(y[i:i+len(w):]*w)/sum(w)
	return y_smooth

def plot(y,bar,w):
	return np.maximum(mov_avg(np.array(y), w),bar)

x=[]
plot1=[]
plot2=[]
plot3=[]
plot4=[]
plot5=[]

with open('comparison_both_models.csv', 'r') as file:
	read = csv.reader(file, delimiter=',')
	for column in read:
		x.append(float(column[0]))
		plot1.append(float(column[1]))
		plot2.append(float(column[2]))
		plot3.append(float(column[3]))
		plot4.append(float(column[4]))
		plot5.append(float(column[5]))

figure= plt.figure(figsize=(15, 9))
ax=figure.add_subplot(111)
mark=2
bar=3e-3

x_min=5200
x_max=8000

acc_time=113.511000

bin_x_start=int(x_min/max(x)*len(x))
bin_x_end=int(x_max/max(x)*len(x))

tail_plot1=np.array(plot1[bin_x_start:bin_x_end:])
tail_plot4=np.array(plot4[bin_x_start:bin_x_end:])
tail_plot5=np.array(plot5[bin_x_start:bin_x_end:])
tail_x=np.array(x[bin_x_start:bin_x_end:])

E_0_1=np.sum((tail_x-x_min)*tail_plot1)/np.sum(tail_plot1)
CR_tail_1=np.sum(tail_plot1)
sig_E_1=E_0_1/np.sqrt(np.sum(tail_plot1)*acc_time)
sig_CR_tail_1=np.sqrt(np.sum(tail_plot1)/acc_time)

E_0_4=np.sum((tail_x-x_min)*tail_plot4)/np.sum(tail_plot4)
CR_tail_4=np.sum(tail_plot4)
sig_E_4=E_0_4/np.sqrt(np.sum(tail_plot4)*acc_time)
sig_CR_tail_4=np.sqrt(np.sum(tail_plot4)/acc_time)

E_0_5=np.sum((tail_x-x_min)*tail_plot5)/np.sum(tail_plot5)
CR_tail_5=np.sum(tail_plot5)
sig_E_5=E_0_5/np.sqrt(np.sum(tail_plot5)*acc_time)
sig_CR_tail_5=np.sqrt(np.sum(tail_plot5)/acc_time)

E_0=[E_0_1, E_0_4, E_0_5]
sig_E_0=[sig_E_1, sig_E_4, sig_E_5]
CR_tail=[CR_tail_1, CR_tail_4, CR_tail_5]
sig_CR_tail=[sig_CR_tail_1,sig_CR_tail_4,sig_CR_tail_5]
z=np.linspace(1,10)
w=[0.1, 0.3, 0.5, 0.8, 1, 0.8, 0.5, 0.3, 0.1]

k=1
dat = np.array([E_0, sig_E_0, CR_tail, sig_CR_tail])
dat = dat.T
np.savetxt('model_tail_comparison.txt', dat,
	header="Slope+_error   TailCR+_error",
	fmt='%3.3f', delimiter = '  ')
ax.semilogy(x[::k],plot(plot1,bar,w)[::k], color='blue', linewidth=2,
	label='high count rate=65kcps')
ax.semilogy(x[::k],plot(plot3,bar,w)[::k], color='green', linewidth=2,
	label='14 kcps data\nscaled up by 65/14')
ax.semilogy(x[::k],plot(plot2,bar,w)[::k], color='orange', linewidth=2,
	label='low count rate=14kcps')
ax.semilogy(x[::k],plot(plot4,bar,w)[::k], color='purple', linewidth=2,
	label='Scaled up data\npiled up using\nrectangular model')
ax.semilogy(x[::k],plot(plot5,bar,w)[::k], color='red', linewidth=2,
	label='Scaled up data\npiled up using\ntrapezoid model')

'''
ax.semilogy(x,plot(plot1,bar,[1]), color=(0,0,1,0.3))
ax.semilogy(x,plot(plot3,bar,[1]), color=(0,1,0,0.3))
ax.semilogy(x,plot(plot2,bar,[1]), color=(1,165.0/255.0,0,0.5))
ax.semilogy(x,plot(plot4,bar,[1]), color=(80/255,0,80/255,0.3))
ax.semilogy(x,plot(plot5,bar,[1]), color=(1,0,0,0.3))
'''
ax.set_xlabel('Energy (eV)',fontsize=30)
ax.set_ylabel('Count rate per energy bin\n(count/s/eV)',fontsize=30)

handles,labels = ax.get_legend_handles_labels()
handles = [handles[0], handles[2], handles[1],handles[3]]
labels = [labels[0], labels[2], labels[1],labels[3]]
ax.legend(handles, labels, loc='best',fontsize= 20)

#ax.legend(loc='best',fontsize= 20)
ax.grid(True, which="both", ls="-.")
plt.xticks(fontsize= 25)
plt.yticks(fontsize= 25)
plt.title("PPR time = 212ns", fontsize=30)
plt.savefig('disparity_log_scale.pdf')
#plt.savefig('comparison_both_models.pdf')
plt.show()






