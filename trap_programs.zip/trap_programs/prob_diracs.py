import matplotlib.pyplot as plt 
import numpy as np


fig=plt.figure(figsize=(15, 8))
ax=fig.add_subplot(111)

ax.plot([],[],'-',color='steelblue',label='a=0.0')
ax.plot([],[],'-',color='darkorange',label='a=0.5')
ax.plot([],[],'-',color='green',label='a=1.0')
ax.plot([0.5,1.47],[1.0,1.0],'k')
ax.plot([0.5,1.485],[0.5,0.5],'k')
ax.plot([0.5,0.5],[0,1],'k')
ax.fill([0.5,1.5,1.5,0.5],[0,0,1,1],color='green')
ax.fill([0.5,1.5,1.5,0.5],[0,0,0.5,0.5],color='darkorange')

a=2

ax.arrow(1.5,0.0,0,1*a,head_width=0.03, head_length=0.03*a,
 linewidth=10, color='k', length_includes_head=False)
ax.arrow(1.5,0.0,0,1*a,head_width=0.03, head_length=0.03*a,
 linewidth=8, color='steelblue', length_includes_head=False)

ax.arrow(1.5,0.0,0,0.5*a,head_width=0.03, head_length=0.03*a,
 linewidth=10, color='k', length_includes_head=False)
ax.arrow(1.5,0.0,0,0.5*a,head_width=0.03, head_length=0.03*a,
 linewidth=8, color='darkorange', length_includes_head=False)


ax.grid()
ax.set_ylim(0,a*1.2)
ax.set_xlim(-0.1,2)
ax.set_ylabel('$p_{2\\gamma}(E|E_1,E_2)$',fontsize=30)
ax.set_xlabel('Energy, E',fontsize=30)
ax.tick_params(labelsize=20)
ax.legend(fontsize=20)
plt.savefig('prob_diracs.pdf')
plt.show()