import matplotlib.pyplot as plt 
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

def dirac(x,s):
	return (-s/2<=x)*(x<=s/2)/s

def heav(x):
	return x>=0

def p_2g(E,E1,E2,a,s):
	A=dirac(E-E1-E2, s)
	B=dirac(E-max(E1,E2),s)
	C=heav(E-max(E1,E2)-s/2)*heav(E1+E2-E-s/2)/min(E1, E2)
	return (1-a)*A+(a/2)*B+(a/2)*C

fig=plt.figure(figsize=(15, 8))
ax=fig.add_subplot(111, projection='3d')


E1=1
E2=0.5
s=0.2
N=9
E=np.linspace(0, 2,100)
a=np.linspace(0,1,100)
E, a = np.meshgrid(E, a)
F=p_2g(E, E1, E2, a, s)
ax.plot_wireframe(E,a,F,linewidth=1, antialiased=False)
ax.grid()
ax.set_zlabel('$p_{2\\gamma}(E|E_1,E_2)$',fontsize=20)
ax.set_xlabel('Energy, E',fontsize=20)
ax.set_ylabel('Triangularity, a',fontsize=20)
ax.tick_params(labelsize=10)
plt.savefig('prob_diracs_alt.pdf')
plt.show()