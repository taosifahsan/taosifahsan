import matplotlib.pyplot as plt
import numpy as np
from scipy import integrate
import math
import sys
import csv

def accum(title):
	if title=='31-14kcps':
		return 61.578000
	if title=='30-23kcps':
		return 85.795000
	if title=='29-34kcps':
		return 59.579000
	if title=='28-50kcps':
		return 59.187000
	if title=='27-62kcps':
		return 113.511000
	else:
		return 113.511000

#include an function defition where we call an array and return an array for real life data
def func(I, x, a):
    i = round(a * len(I) / x[len(I) - 1])
    N = len(I)
    if i < N:
        return I[round(a * len(I) / x[len(I) - 1])]
    else:
        return 0

title=str(sys.argv[2])
title_csv=title+'.csv'
x=[]
y=[]
with open(title_csv, 'r') as file:
	read = csv.reader(file, delimiter=' ')
	for column in read:
		y_0.append(float(column[0]))

total_count=np.sum(y_0)
acc_time=accum(title)
count_rate=total_count/acc_time
t_f=(200+12+200)
t_e=12
trngl_ness=1-t_e/t_f
utf=count_rate*t_f*10**(-9)

for i in range(len(y)):
	y[i]=y[i]/acc_time

lin=np.linspace(1,len(y),len(y))
M=8.8014
B=-25.2794
x=M*lin+B

#range and accuracy
start=x[0]
end=x[len(x)-1]
accuracy=len(x)

#incidence distribution, change at will
f = lambda E: func(y,x,E)

#normalizing the distribution
norm = integrate.quad(lambda x: f(x),start,end)[0]
fI = lambda E : f(E)/norm

#integrals
fA = lambda E : integrate.quad(lambda x: fI(x)*fI(E-x),0,E)[0]
fB = lambda E : integrate.dblquad(lambda y, x: fI(x)*fI(y)/y, E/2, E, lambda x: E-x, lambda x: x)[0]
fC = lambda E : fI(E)*(integrate.quad(lambda x: fI(x),0,E)[0])

E=np.linspace(start,end*2,N*2)

I=[]
A=[]
B=[]
C=[]
#creating arrays from defined integral
for i in range(len(E)):
    	I = np.append(I, fI(E[i]))
    	A = np.append(A, fA(E[i]))
    	B = np.append(B, fB(E[i]))
    	C = np.append(C, fC(E[i]))

font = {'fontname':'Times'}
plot=[]
for i in range(len(I)):
	plot=np.append(plot,I[i]*(1-utf)+utf*((1-trngl_ness)*A[i]+trngl_ness*B[i]+trngl_ness*C[i]))
plt.plot(x_axis,np.log(norm*plot)/np.log(10),linewidth=1)

plt.xlabel('Energy (ev)', **font)
plt.ylabel('log of count rate (count/s)', **font)

#plot for double logarithmic graph. Enter dblog in terminal after .py to execute
plt.title('title', **font)
plt.legend()
plt.grid()
plt.show()


