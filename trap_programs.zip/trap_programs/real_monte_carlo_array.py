import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from scipy import integrate
import math
import sys
import csv

#accumalation from file to keep things running fast
def accum(title):
	if title=='31-14kcps':
		return 61.578000
	if title=='30-23kcps':
		return 85.795000
	if title=='29-34kcps':
		return 59.579000
	if title=='28-50kcps':
		return 59.187000
	if title=='27-62kcps':
		return 113.511000
	else:
		return 113.511000

#turning array into function
def func(I,x,a):
	i=round(a*len(I)/x[len(I)-1])
	N=len(I)
	
	if a<float(sys.argv[3]):
		return I[round(a*len(I)/x[len(I)-1])]
	else: 
		return 0

#reading array
title=str(sys.argv[2])
x=[]
y=[]
with open(title, 'r') as file:
	read = csv.reader(file, delimiter=' ')
	for column in read:
		y.append(float(column[0]))

total_count=np.sum(y)
acc_time=accum(title)
count_rate=total_count/acc_time
t_f=(200+12+200)
t_e=12
trngl_ness=1-t_e/t_f
utf=count_rate*t_f*10**(-9)

for i in range(len(y)):
	y[i]=y[i]/acc_time

lin=np.linspace(1,len(y),len(y))
M=8.8014
B=-25.2794
x=M*lin+B

#overlap probablity
start=x[0]
end=x[len(x)-1]
accuracy=len(x)
N=int(sys.argv[1])

#the function
fI=lambda E: func(y,x,E)

#normalizing the function
norm=0
for E in x:
	norm+=fI(E)*(end-start)/accuracy

f=lambda E: fI(E)/norm

#initiating the arrays
I=[]
A=[]
B=[]
C=[]

x_axis=np.linspace(start,end,accuracy)

#monte carlo simulation starts
for a in x_axis:
	I=np.append(I,f(a))

for a in x_axis:
	sum=0
	for i in range(N):
		E=random.uniform(0,a)
		if(E<a):
			sum+=f(E)*f(a-E)
	A=np.append(A,sum*a/N)
		
for a in x_axis:
	sum=0
	for i in range(N):

    		E_x=random.uniform(a/2,a)
    		E_y=random.uniform(0,a)

    		if((E_x>E_y) and (E_x+E_y>a)) and (a>E_x):
        		sum+=f(E_x)*f(E_y)/E_y

	B=np.append(B,sum*(a**2/2/N))

for a in x_axis:
	sum=0
	for i in range(N):
		E_x=random.uniform(0,a)
		if(E_x<a):
			sum+=f(E_x)
	C=np.append(C,f(a)*sum*a/N)

#plotting the graphs
font = {'fontname':'Times'}
plot=[]
for i in range(len(I)):
	plot=np.append(plot,I[i]*(1-utf)+utf*((1-trngl_ness)*A[i]+trngl_ness*B[i]+trngl_ness*C[i]))
plt.plot(x_axis,np.log(norm*plot)/np.log(10),linewidth=1)

plt.xlabel('Energy (ev)', **font)
plt.ylabel('log of count rate (count/s)', **font)

plt.title('overlap probablity='+str(round(utf,5))+'\n'+title, **font)
plt.legend()
plt.grid()
plt.show()
