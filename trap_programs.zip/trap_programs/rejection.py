import sys
import numpy as np
import random
import matplotlib.pyplot as plt

u=10**5
u_n=10**5

n=4
unit=100/n
time=10**7
time_rejection=10000/unit
time_filter=100/unit

p=10**(-9)*unit*u
p_n=10**(-9)*unit*u_n
#time_impossible=100
bin=np.linspace(0,0,1000)
bin_n=np.linspace(0,0,1000)
last_count_t=0
count=0

for i in range(int(time/time_rejection)):
	count=0
	tot_count_in=0
	for j in range(int(time_rejection/time_filter)):
		count_in=0
		for k in range(int(time_filter)):
			pop=np.random.random()<p
			count_in+=pop
		count+=(count_in>0)
		tot_count_in+=count_in
	bin[tot_count_in]+= (count==1)

for i in range(int(time/time_rejection)):
	count=0
	for j in range(int(time_rejection)):
		pop=np.random.random()<p_n
		count+=pop
	bin_n[count]+=(count>0)

fig, axs=plt.subplots(1,2)
for i in range(10):
	axs[0].plot([i,i],[0,bin[i]/sum(bin)*100],'b-',markersize=5)
	axs[1].plot([i,i],[0,bin_n[i]/sum(bin_n)*100],'r-',markersize=5)

axs[0].plot(bin[:10]/sum(bin)*100+1/10**5,'bo',markersize=5)
axs[1].plot(bin_n[:10]/sum(bin_n)*100+1/10**5,'ro',markersize=5)
axs[0].grid(True, which="both", ls="-.")
axs[1].grid(True, which="both", ls="-.")

axs[0].set_xlabel('Energy')
axs[0].set_ylabel('Probablity Spectrum %')
axs[1].set_xlabel('Energy')
axs[1].set_ylabel('Probablity Spectrum %')

axs[0].set_title('Pile Up Rejection, CR=%.2e cps'%(u))
axs[1].set_title('CR=%.2e cps'%(u_n))
plt.show()


	