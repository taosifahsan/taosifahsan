import matplotlib.pyplot as plt 
import numpy as np
fig=plt.figure(figsize=(10, 10))
ax=fig.add_subplot(111)

font = {'fontname' : 'Times',
		'size'	   : 30}

font1 = {'fontname' : 'Times',
		'size'	   : 20}

N=500
slab_x=[]
slab_y=[]

for i in range(N):
	for j in range(N):
		x=i/N
		y=j/N
		if (x+y>=1)*(x>=y)*(0.7<=x)*(x<=0.75):
			slab_x=np.append(slab_x,x)
			slab_y=np.append(slab_y,y)

ax.plot(slab_x,slab_y,'.',markersize=1,color='cornflowerblue')

box_x=[]
box_y=[]

for i in range(N):
	for j in range(N):
		x=i/N
		y=j/N
		if (0.7<=x)*(x<=0.75)*(0.6<=y)*(y<=0.65):
			box_x=np.append(box_x,x)
			box_y=np.append(box_y,y)

ax.plot(box_x,box_y,'.',markersize=1,color='navy')

ax.plot([0.5,1,1,0.5],[0.5,0,1,0.5],'k',lw=2)
ax.plot([0.5,0.5],[0.5,0],'k--',lw=1)
ax.plot([0.7,0.7],[0.3,0.0],'k--',lw=1)
ax.plot([0.75,0.75],[0.25,0.0],'k--',lw=1)
ax.plot([-0.1,0.725],[0.725,0.725],'k--',lw=1)
ax.plot([-0.1,0.725],[0.275,0.275],'k--',lw=1)
ax.plot([-0.1,0.75],[0.6,0.6],'k--',lw=1)
ax.plot([-0.1,0.75],[0.65,0.65],'k--',lw=1)
ax.plot([0.7,0.7],[0.7,0.3],'k',lw=2)
ax.plot([0.75,0.75],[0.75,0.25],'k',lw=2)


ax.text(0.5,-0.05,'E/2',fontsize=25)#**font1)
ax.text(1.0,-0.05,'E',fontsize=25)#**font1)
ax.text(0.7,-0.05,'dE$_1$',fontsize=25)#**font1)
ax.text(-0.05,0.61,'dE$_2$',fontsize=25)#**font1)
ax.text(-0.05,0.74,'E$_1$',fontsize=25)#**font1)
ax.text(-0.05,0.29,'E-E$_1$',fontsize=25)#**font1)

ax.grid()
plt.xlabel('E$_1$',fontsize=30)#,**font)
plt.ylabel('E$_2$',fontsize=30)#,**font)
plt.xticks(fontsize=30)#**font1)
plt.yticks(fontsize=30)#**font1)
plt.axis('square')
plt.xlim(-0.1,1.1)
plt.ylim(-0.1,1.1)
plt.savefig('slabs.pdf')
plt.show()