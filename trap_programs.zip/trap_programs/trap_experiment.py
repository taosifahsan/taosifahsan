import sys
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import LinearSegmentedColormap

def trap(t,t_0,t_p,a,E):
	t_e=t_p*(1-a)
	t_r=(t_p-t_e)/2
	F_r=((t-t_0)*E/t_r)*(t_0<=t)*(t<t_0+t_r)
	F_e=E*(t_0+t_r<=t)*(t<=t_0+t_r+t_e)
	F_f=(t_0+t_p-t)*E/t_r*(t_0+t_r+t_e<t)*(t<=t_0+t_p)

	return F_r+F_e+F_f

def trap_add(t,t_arr,t_p,a,E_arr):
	trap_add=np.array([0.0]*len(t))
	for i in range(len(t_arr)):
		trap_add+=trap(t,t_arr[i],t_p,a,E_arr[i])
	return trap_add


N=30
E_max=np.array([[0.0]*N]*N)
E_max_1=np.array([[0.0]*N]*N)
tp=1
a=1
t=np.linspace(0,tp*(1-1/N),N)
x=np.linspace(0,tp*(1-1/N),N)
y=np.linspace(0,tp*(1-1/N),N)
x,y=np.meshgrid(x,y)
e1,e2,e3=(2,3,4)

E_arr=[e1,e2,e3]

fig=plt.figure(figsize=(6,6))
fig.set_facecolor('black')
ax=fig.add_subplot(111,projection='3d')
ax.set_facecolor('black') 

for i in range(N):
	for j in range(N):
		t_arr=[0,t[i],t[j]]
		t_arr_1=[t[i],t[j],0]
		E=trap_add(t,t_arr,tp,a,E_arr)
		E_1=trap_add(t, t_arr_1, tp, a, [E_arr[2],E_arr[1],E_arr[0]])
		E_max[i][j]=E.max()
		E_max_1[j][i]=E_1.max()


DE_x=np.array([[0.0]*N]*N)
DE_y=np.array([[0.0]*N]*N)

for i in range(N-1):
	for j in range(N-1):
		DE_x[i][j]=(E_max[i+1][j]-E_max[i][j])/(t[1]-t[0])
		DE_y[i][j]=(E_max[i][j+1]-E_max[i][j])/(t[1]-t[0])
	DE_y[i][N-1]=DE_x[i][N-2]

for j in range(N-1):
	DE_y[N-1][j]=DE_y[N-2][j]

F=(DE_x*DE_y)
ax.set_xlim(0,t[N-1])
ax.set_ylim(0,t[N-1])
ax.set_zlim(0,e1+e2+e3)
x_0=(e2+2*e3-e1)/(2*e3)*tp
y_0=(e3+2*e2-e1)/(2*e2)*tp

ax.xaxis._axinfo['tick']['color']='white'
ax.yaxis._axinfo['tick']['color']='white'
ax.zaxis._axinfo['tick']['color']='white'
ax.tick_params(axis='x', colors='white')
ax.tick_params(axis='y', colors='white')
ax.tick_params(axis='z', colors='white')

ax.w_xaxis.set_pane_color((0.0, 0.0, 0.0, 1.0))
ax.w_yaxis.set_pane_color((0.0, 0.0, 0.0, 1.0))
ax.w_zaxis.set_pane_color((0.0, 0.0, 0.0, 1.0))

'''
ax.plot(x_0,0.5,e1,'wo')
ax.plot(0.5,y_0,e1,'wo')
ax.plot(0.5,0.5,e3+e2,'wo')
ax.plot(0.5,0.0,e1+e2,'wo')

ax.plot(0.0,0.5,e1+e3,'wo')
ax.plot(0.0,0.0,e1+e3+e2,'wo')
ax.plot(0.0,1.0,e1+e3,'wo')
ax.plot(1.0,0.0,e1+e2,'wo')
ax.plot(1.0,0.5,e1,'wo')
ax.plot(0.5,1.0,e1,'wo')
ax.plot(1.0,1.0,e1,'wo')
'''



ax.plot_wireframe(x,y, E_max)
ax.plot_wireframe(x,y, E_max_1)
ax.plot(t,[0.5]*len(t),(e3+e2-e1)/(0.5*tp-x_0)*(t-x_0)+e1,'r-')
ax.plot([0.5]*len(t),t,(e3+e2-e1)/(0.5*tp-y_0)*(t-y_0)+e1,'r-')
ax.plot(t,e3/e2+1-e1/2/e2-e3*t/e2,e1,'r-')
ax.plot(t,t,e2+e3+e1*(tp-2*t),'r-')
ax.plot(t,0.5*tp/(x_0-0.5*tp)*(t-0.5*tp),e1+e2-e2/(x_0-0.5*tp)*(t-0.5*tp),'r-')
ax.plot(0.5*tp/(y_0-0.5*tp)*(t-0.5*tp),t,e1+e3-e3/(y_0-0.5*tp)*(t-0.5*tp),'r-')
#ax.plot(t,(e3+e2-e1)/e2*t+tp/2,e1,'r-')
#ax.plot((e3+e2-e1)/e3*t+tp/2,t,e1,'r-')
#ax.plot_wireframe(x,y,2*(e2+e3)-2*e3*x/tp-2*e2*y/tp)
#ax.plot_wireframe(x,y,e1+e2+e3-2*(e1-e2)/tp*x-2*e2/tp*y)
#ax.plot_wireframe(x,y,e1+e2+e3-2*(e1-e3)/tp*y-2*e3/tp*x)
#ax.plot_wireframe(x,y,e1+e3-2*e3/tp*x)
#ax.plot_wireframe(x,y,e1+e2-2*e2/tp*y)
plt.xlabel('$\\Delta t_2$',color='white',fontsize=20)
plt.ylabel('$\\Delta t_3$',color='white',fontsize=20)
plt.show()




