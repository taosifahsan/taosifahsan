import matplotlib.pyplot as plt 
import numpy as np


fig=plt.figure(figsize=(15, 8))
ax=[None]*4
xp=[0]*4
g=[None]*4
ax[0]=fig.add_subplot(221)
ax[1]=fig.add_subplot(222)
ax[2]=fig.add_subplot(223)
ax[3]=fig.add_subplot(224)

font = {'fontname' : 'Times',
		'size'	   : 25}

x=np.linspace(0,6.5,1000)

f=((1<=x)*(x<2)*(x-1)+(2<=x)*(x<=3)+(3<x)*(x<=4)*(4-x))*0.5

for i in range(4):
	xp[i]=x-(0.75+i*0.5)
	g[i]=((1<=xp[i])*(xp[i]<2)*(xp[i]-1)+(2<=xp[i])*(xp[i]<=3)+(3<xp[i])*(xp[i]<=4)*(4-xp[i]))



for i in range(4):
	ax[i].plot(x,f)
	ax[i].plot(x,g[i])
	ax[i].plot(x,f+g[i])
	ax[i].grid()
	ax[i].set_ylim(0,1.6)
	ax[i].set_xlabel('time, t',fontsize=25)# **font)
	ax[i].set_ylabel('voltage, V(t)',fontsize=25)#, **font)
	ax[i].tick_params(labelsize=15)

ax[0].plot([3,6],[1.5,1.5],'k--')
ax[0].plot([3.75,6],[1.0,1.0],'k--')
ax[0].plot([3,6],[0.5,0.5],'k--')


ax[0].plot([1,1],[0,2],'r')
ax[0].plot([3,3],[0,2],'r')
ax[2].arrow(2, 1.4, -1, 0, head_width=0.02, head_length=0.02, linewidth=2, color='r', length_includes_head=True)
ax[2].arrow(2, 1.4, 1, 0, head_width=0.02, head_length=0.02, linewidth=2, color='r', length_includes_head=True)
ax[2].text(1.25,1,'region \n of PPU',fontsize=20)

ax[1].plot([1,1],[0,2],'r')
ax[1].plot([3,3],[0,2],'r')
ax[2].plot([1,1],[0,2],'r')
ax[2].plot([3,3],[0,2],'r')
ax[3].plot([1,1],[0,2],'r')
ax[3].plot([3,3],[0,2],'r')

ax[0].plot([0.5,2.75],[1.5,1.5],'b--')
ax[0].text(0.05,1.35,'max',fontsize=20)
ax[1].plot([0.5,3],[1.25,1.25],'b--')
ax[1].text(0.05,1.1,'max',fontsize=20)
ax[2].plot([0.5,3],[0.75,0.75],'b--')
ax[2].text(0.05,.6,'max',fontsize=20)
ax[3].plot([0.5,3],[0.5,0.5],'b--')
ax[3].text(0.05,0.35,'max',fontsize=20)



ax[0].text(4.2,1.3,'$\\propto (E_1+E_2)$',fontsize=25)
ax[0].text(5,0.8,'$\\propto E_1$',fontsize=25)
ax[0].text(5,0.3,'$\\propto E_2$',fontsize=25)

ax[0].arrow(1.5, 0.03, 0.244, 0, head_width=0.02, head_length=0.02, linewidth=2, color='k', length_includes_head=True)
ax[0].arrow(1.5, 0.03, -0.44, 0, head_width=0.02, head_length=0.02, linewidth=2, color='k', length_includes_head=True)
ax[0].text(1.2,0.05,'$\\Delta t$',fontsize=25)

ax[1].plot([3.75+0.5-1.25,3.75+0.5-1.25],[0,0.5],'k--')
ax[1].arrow(3.75-0.5+0.5-1.25, 0.03, 0.44, 0, head_width=0.02, head_length=0.02, linewidth=2, color='k', length_includes_head=True)
ax[1].arrow(3.75-0.5+0.5-1.25, 0.03, -1.44, 0, head_width=0.02, head_length=0.02, linewidth=2, color='k', length_includes_head=True)

ax[1].text(3.55-0.5+0.25-1.25,0.12,'$t_p$',fontsize=25)

ax[1].plot([3.25-1.25,3.25-1.25],[0,0.5],'k--')
ax[1].arrow((2.25+3.25)/2-1.25, 0.1, -(2.25-3.25)/2-0.05, 0, head_width=0.02, head_length=0.02, linewidth=2, color='k', length_includes_head=True)
ax[1].arrow((2.25+3.25)/2-1.25, 0.1, (2.25-3.25)/2+0.05, 0, head_width=0.02, head_length=0.02, linewidth=2, color='k', length_includes_head=True)

ax[1].text((2.25+3.25)/2-0.25-1.25,0.12+0.1-0.03,'$t_r$',fontsize=25)

ax[1].arrow(3.75-0.5-1.25+0.5, 0.53, 0.44, 0, head_width=0.02, head_length=0.02, linewidth=2, color='k', length_includes_head=True)
ax[1].arrow(3.75-0.5-1.25+0.5, 0.53, -0.44, 0, head_width=0.02, head_length=0.02, linewidth=2, color='k', length_includes_head=True)

ax[1].text(3.55-0.5-1.25+0.5,0.58,'$t_f$',fontsize=25)

ax[0].set_title('$\\Delta t \\leq t_f$',fontsize=25)#, **font)
ax[1].set_title('$t_f \\leq \\Delta t \\leq t_p $',fontsize=25)#, **font)
ax[2].set_title('$t_f \\leq \\Delta t \\leq t_p $',fontsize=25)#, **font)
ax[3].set_title('$ t_p \\leq \\Delta t $',fontsize=25)#, **font)

fig.subplots_adjust(hspace=0.45)
plt.savefig('different_case_trapezoid.pdf')
plt.show()